package com.meterstoinches.sensor;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    SensorManager sm;
    Sensor mysensor;
    TextView outputX,outputY,outputZ;
    LinearLayout ln;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity1);
        outputX=findViewById(R.id.textView1);
        outputY=findViewById(R.id.textView2);
        outputZ=findViewById(R.id.textView3);
        ln=findViewById(R.id.mylayout);
        sm=(SensorManager) getSystemService(SENSOR_SERVICE);
        mysensor=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sm.registerListener(this,mysensor,sm.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onStop() {
        super.onStop();
        sm.unregisterListener(this,mysensor);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float [] values= event.values;
        float accX = values[0];
        float accY=values[1];
        float accZ=values[2];
        outputX.setText("X: "+(int)accX);
        outputY.setText("Y: "+(int)accY);
        outputZ.setText("Z: "+(int)accZ);

        if(accX>9){ln.setBackgroundResource(R.mipmap.ic_kate);};
        if(accY>9){ln.setBackgroundResource(R.mipmap.ic_lemma);};
        if(accZ>9){ln.setBackgroundResource(R.mipmap.ic_emma);};

        /*
        if(((accX*accX)+(accY*accY)+(accZ*accZ)>100)){ln.setBackgroundColor(Color.GREEN);}
        else {ln.setBackgroundColor(Color.BLUE);};*/
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
